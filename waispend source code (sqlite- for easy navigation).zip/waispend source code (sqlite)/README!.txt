Guide to set-up the file:No xampp needed(Much better to use VScode):
1) Go to path folder where manage.py is located.

2) Set-up | Execute the following inside the terminal:
- pip install django==3.2
- pip install mysqlclient
- pip install pillow

3) Start-up | Execute the following inside the terminal:
- pip manage.py makemigrations
- pip manage.py migrate
- pip manage.py runserver

4) Navigate the browser | can now log-in precreated users:
- go to: http://127.0.0.1:8000/

To be able to see all data,log-in the admin: 

Admin
username: admin
password: 123
 
users:
username: jdelacruz
password: MyValentine1234

username:jolly_bee
password:BidaAngSaya321

username:brimsmoke
password: Valorant123

5) Create own admin (optional) | Execute the following inside the terminal:
- pip manage.py createsuperuser
//enter credentials
- pip manage.py runserver


