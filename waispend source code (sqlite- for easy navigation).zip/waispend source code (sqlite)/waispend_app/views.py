from multiprocessing import context
from pyexpat.errors import messages
from django.shortcuts import render,redirect
from django.urls import reverse
from django.http import HttpResponse, HttpResponseRedirect, Http404, request
from django.contrib.auth import authenticate, login, update_session_auth_hash, logout
from django.contrib.auth.forms import PasswordChangeForm
from .models import *
from django.contrib.auth.models import User
from .forms import CreateUserForm
from django.contrib import messages
import random
import json

# Create your views here.

def index(request):
    return render(request, 'index.html')

def about_us(request):
    return render(request, 'about_us.html')

def profile(request):
    if request.user.is_authenticated:
        return render(request, 'profile.html')
    else:
        return redirect('login')

def edit(request):
    if request.user.is_authenticated:
        id= request.user.id
        info = User.objects.get(pk=id)
        if request.method == 'POST':
            info.first_name = request.POST.get('first_name')
            info.last_name = request.POST.get('last_name')
            info.save()
            messages.success(request, 'Profile Updated!')
            return redirect('home')
        return render(request, 'edit.html')  
    else:
        return redirect('login')

def security(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)
                messages.success(request, 'Password Updated!')
                return redirect('home')
            else:
                messages.error(request, 'Your password must contain at least 1 uppercase letter, A-Z.')
                messages.error(request, 'Your password must contain at least 1 lowercase letter, a-z.')
                messages.error(request, 'Your password must contain at least 1 symbol character, /@!.')
                messages.error(request, 'Your password must have 8 minimum characters.')
                messages.error(request, '"Re-typed password must match to the new password"')
        else:
            form = PasswordChangeForm(request.user)
        return render(request, 'security.html', {'form': form})
        
    else:
        return redirect('login')

def sign_up(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)     
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('first_name')
                messages.success(request,'Account successfully created! Hello ' + user + '!')
                return redirect('login')
            else:
                password1 = form.data['password1']
                password2 = form.data['password2']
                username = form.data['username']
                email = form.data['email']
                for error in form.errors.as_data():
                    if error == 'email':
                        messages.error(request, f"Declared {email} is not valid")
                    if username == 'username':
                        messages.error(request, f"Declared {username} is not valid")                    
                    if error == 'password2' and password1 == password2:
                        messages.error(request, f"Selected password is not strong enough")
                    elif error == 'password2' and password1 != password2:
                        messages.error(request, f"Passwords do not match")
        context = {'form':form}
        return render(request, 'sign_up.html', context )

    
def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                if user.is_superuser:
                    return redirect('/admin')
                else:
                    id = request.user.id
                    user = User.objects.get(pk=id)
                    getbudget = budget.objects.filter(userID=user.id)
                    count = 0
                    for budgets in getbudget:
                        count = count + 1
                    if count == 0:
                        return redirect('createbudget')
                    else:
                        return redirect('home')
            else:
                messages.info(request, 'Username OR password is incorrect')
                return render(request, 'login.html')
    return render(request, 'login.html')

def logoutUser(request):
    logout(request)
    return redirect('login')

def home(request):
    if request.user.is_authenticated:
        id = request.user.id
        user = User.objects.get(pk=id)
        getbudget = budget.objects.filter(userID=user.id)
        return render(request, 'waispend_app/home.html',{'getbudget': getbudget})
    else:
        messages.success(request,'Successfully added!')
        return redirect('login')
    

def createbudget(request):
    if request.user.is_authenticated:
        return render(request, 'waispend_app/createbudget.html')
    else:
        return redirect('login')
        

def range_name(request):
    if request.user.is_authenticated:
        id = request.user.id
        user = User.objects.get(pk=id)
        if request.method == 'POST':
            budgetPurpose = request.POST.get('budgetPurpose')
            budgetName = request.POST.get('budgetName')
            budgetRange = request.POST.get('datefilter')
            budgetset = budget(userID=user,budgetName=budgetName,budgetPurpose=budgetPurpose,budgetRange=budgetRange)
            budgetset.save()
            messages.success(request,'Successfully added!')  
            return redirect('home')
    else:
        return redirect('login')
    return render(request, 'waispend_app/category_range_display.html')

def select_category_income(request, budget_id):
    if request.user.is_authenticated:
        budgets= budget.objects.get(pk=budget_id)
        incomes = income.objects.filter(budgetID=budgets)
        if request.method == 'POST':
            incomeCategories = request.POST.get('disposable-income')
            incomeAmount = request.POST.get('estimated-income')
            incomeset = income(budgetID=budgets,incomeAmount=incomeAmount,incomeCategories=incomeCategories)
            incomeset.save()
            messages.success(request,'Successfully added!')
        return render(request, 'waispend_app/select_category_income.html', {'budgets': budgets, 'incomes':incomes})
    else: 
        return redirect('login')


def default_view(request, budget_id):
    if request.user.is_authenticated:
        budgets= budget.objects.get(pk=budget_id)
        incomes = income.objects.filter(budgetID=budgets)
        expense = expenses.objects.filter(budgetID=budgets)
        total_income = 0.00
        total_budget = 0.00
        total_expend = 0.00
        for totalins in incomes:
            x = float(totalins.incomeAmount)
            total_income = total_income + x
        budgets.totalIncome = total_income
        budgets.save()
        for totalbud in expense:
            x = float(totalbud.expensesAmount)
            total_budget = total_budget + x
        budgets.totalBudgeted = total_budget
        budgets.save()
        for totalex in expense:
            x = float(totalex.expensesTotal)
            total_expend = total_expend + x
        budgets.totalExpense = total_expend
        budgets.save()
        budgets.totalRemain = float(budgets.totalBudgeted) - float(budgets.totalExpense)
        budgets.save()      
        budgets.provBalance = float(budgets.totalIncome) - float(budgets.totalBudgeted)
        budgets.save()  
        budgets.savings = float(budgets.totalRemain) + float(budgets.provBalance)
        budgets.save() 
        if  budgets.totalBudgeted > 0.00:
            budgets.ave_spent = (float(budgets.totalExpense)/float(budgets.totalBudgeted)) * 100
            budgets.save()
        else:
            budgets.ave_spent = 0
            budgets.save()
        if  budgets.totalIncome > 0.00:
            budgets.ave_income_spent = (float(budgets.totalExpense)/float(budgets.totalIncome))
            budgets.save()
        else:
            budgets.ave_income_spent = 0
            budgets.save()
        context = {'budgets': budgets,'incomes': incomes,'expense':expense}
        return render(request, 'waispend_app/default_view_newuser.html', context)
    else:
        return redirect('login')



def select_category_expenses(request,budget_id):
    if request.user.is_authenticated:
        budgets= budget.objects.get(pk=budget_id)
        expense = expenses.objects.filter(budgetID=budgets)
        if request.method == 'POST':
            expensesCategories = request.POST.get('budget-expenses')
            expensesAmount = request.POST.get('estimated-budget')
            expenseset = expenses(budgetID=budgets,expensesAmount=expensesAmount,expensesCategories=expensesCategories)
            expenseset.save()
            messages.success(request,'Successfully added!')
        return render(request, 'waispend_app/select_category_expense.html', {'budgets': budgets, 'expense':expense})
    else: 
        return redirect('login')

def add_expense(request,budget_id,add_id):
    if request.user.is_authenticated:
        expense = expenses.objects.get(pk=add_id)
        budgets= budget.objects.get(pk=budget_id)
        if request.method == 'POST':
            description = request.POST.get('description')
            amountSpent = request.POST.get('amountSpent')
            transactionDate = request.POST.get('transactionDate')
            expenseset = expenseSpent(expenseID=expense,description=description,amountSpent=amountSpent,transactionDate=transactionDate)
            expenseset.save()
            messages.success(request,'Successfully added!')
        spent = expenseSpent.objects.filter(expenseID=expense)
        totalspent = 0.00
        for spending in spent:
            x = float(spending.amountSpent)
            totalspent = totalspent + x
        expense.expensesTotal = totalspent
        expense.save()
        expense.balanceRemain = float(expense.expensesAmount) - float(expense.expensesTotal)
        expense.save() 
        expense.ave_spent = (int(expense.expensesTotal)/int(expense.expensesAmount)) * 100
        expense.save() 
        return render(request, 'waispend_app/add_expense.html', {'expense':expense,'budgets': budgets})
    else: 
        return redirect('login')

def delete_income(request, budget_id, income_id):
    incomes = income.objects.get(id = income_id)
    if request.method =='POST':
        incomes.delete()
        messages.success(request, 'Successfully removed!')
        return HttpResponseRedirect(reverse('select_category_income', args=[str(budget_id)]))
    context = {'incomes': incomes}
    return render(request, 'waispend_app/delete_income.html', context)



def delete_expense(request, budget_id, expense_id):
    expense = expenses.objects.get(id = expense_id)
    if request.method =='POST':
        expense.delete()
        messages.success(request, 'Successfully removed!')
        return HttpResponseRedirect(reverse('select_category_expenses', args=[str(budget_id)]))
    context = {'expense': expense}
    return render(request, 'waispend_app/delete_expenses.html', context)

def delete_budget(request, budget_id):
    bud = budget.objects.get(id = budget_id)
    if request.method =='POST':
        bud.delete()
        messages.success(request, 'Successfully removed!')
        return redirect('home')
    context = {'bud': bud}
    return render(request, 'waispend_app/delete_budget.html', context)


def budgets_charts(request):
    if request.user.is_authenticated:
        id = request.user.id
        user = User.objects.get(pk=id)
        getbudget = budget.objects.filter(userID=user.id)
        return render(request, 'waispend_app/budgets_charts.html',{'getbudget': getbudget})
    else:
        return redirect('login')


def chart_overview(request, budget_id):
    if request.user.is_authenticated:
        budgets= budget.objects.get(pk=budget_id)
        incomes = income.objects.filter(budgetID=budgets)
        expense = expenses.objects.filter(budgetID=budgets)
        total_income = 0.00
        total_budget = 0.00
        total_expend = 0.00
        for totalins in incomes:
            x = float(totalins.incomeAmount)
            total_income = total_income + x
        budgets.totalIncome = total_income
        budgets.save()
        for totalbud in expense:
            x = float(totalbud.expensesAmount)
            total_budget = total_budget + x
        budgets.totalBudgeted = total_budget
        budgets.save()
        for totalex in expense:
            x = float(totalex.expensesTotal)
            total_expend = total_expend + x
        budgets.totalExpense = total_expend
        budgets.save()
        budgets.totalRemain = float(budgets.totalBudgeted) - float(budgets.totalExpense)
        budgets.save()      
        budgets.provBalance = float(budgets.totalIncome) - float(budgets.totalBudgeted)
        budgets.save()  
        budgets.savings = float(budgets.totalRemain) + float(budgets.provBalance)
        budgets.save() 
        if  budgets.totalBudgeted > 0.00:
            budgets.ave_spent = (float(budgets.totalExpense)/float(budgets.totalBudgeted)) * 100
            budgets.save()
        else:
            budgets.ave_spent = 0
            budgets.save()
        if  budgets.totalIncome > 0.00:
            budgets.ave_income_spent = (float(budgets.totalExpense)/float(budgets.totalIncome))
            budgets.save()
        else:
            budgets.ave_income_spent = 0
            budgets.save()
        labels = []
        data = []
        colors = []
        for bud in expense:
            color = "#" + "%06x" % random.randint(0, 0xFFFFFF)
            labels.append(bud.expensesCategories)
            data.append(str(bud.expensesAmount))
            colors.append(color)
        if budgets.provBalance > 0:
            unused = 'Unused'
            amount = budgets.provBalance
            clr = '#808080'
            labels.append(unused)
            data.append(str(amount))
            colors.append(clr)
        else:
            pass
        context = {'budgets': budgets,'incomes': incomes,'expense':expense,'labels' : labels, 'data' : data, 'colors': colors}
        return render(request, 'waispend_app/chart_overview.html',context)
    else:
        return redirect('login')


