from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls import url
from . import views 
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.views.static import serve

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'about_us', views.about_us, name='about_us'),
    url(r'home', views.home, name="home"),
    url(r'login', views.loginPage, name="login"),
    url(r'logout', views.logoutUser, name="logout"),
    url(r'^createbudget$', views.createbudget, name='createbudget'),

    url(r'profile', views.profile, name='profile'),
    url(r'edit', views.edit, name='edit'),
    url(r'security', views.security, name='security'),

    url(r'^range_name$', views.range_name, name='range_name'),
    url(r'^select_category_income/(?P<budget_id>[a-zA-Z0-9]+$)', views.select_category_income, name='select_category_income'),
    url(r'^select_category_expenses/(?P<budget_id>[a-zA-Z0-9]+$)', views.select_category_expenses, name='select_category_expenses'),
    url(r'^default_view/(?P<budget_id>[a-zA-Z0-9]+$)', views.default_view, name='default_view'),
    url(r'^add_expense/(?P<budget_id>[a-zA-Z0-9]+)/(?P<add_id>[a-zA-Z0-9]+$)', views.add_expense, name='add_expense'),
    url(r'^sign_up$', views.sign_up, name='sign_up'),
    url(r'^delete_income/(?P<budget_id>[a-zA-Z0-9]+)/(?P<income_id>[a-zA-Z0-9]+$)', views.delete_income, name='delete_income'),
    url(r'^delete_expenses/(?P<budget_id>[a-zA-Z0-9]+)/(?P<expense_id>[a-zA-Z0-9]+$)', views.delete_expense, name='delete_expenses'),
    url(r'^delete_budget/(?P<budget_id>[a-zA-Z0-9]+$)', views.delete_budget, name='delete_budget'),
    url(r'^budgets_charts$', views.budgets_charts, name='budgets_charts'),
    url(r'^chart_overview/(?P<budget_id>[a-zA-Z0-9]+$)', views.chart_overview, name='chart_overview'),
]  + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) \
              + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
