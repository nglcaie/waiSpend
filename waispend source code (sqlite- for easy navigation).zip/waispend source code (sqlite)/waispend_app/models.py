from django.db import models
from django.contrib.auth.models import User
from django.db.models.deletion import CASCADE
from datetime import datetime
from django.db.models.fields.related import ForeignKey
from django.utils import timezone
# Create your models here.


class budget(models.Model):
    userID = models.ForeignKey(User, verbose_name='User', on_delete=models.CASCADE)
    budgetName = models.CharField(max_length=100, verbose_name="Budget Name",null=True, blank = True)
    budgetPurpose = models.CharField(max_length=100, verbose_name="Purpose",null=True, blank = True)
    totalIncome = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Total Income")
    totalBudgeted = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Total Expenditures")
    totalExpense = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Total Budget Spent")
    totalRemain = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Remaining to Spent")
    provBalance = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Provisional Balance")
    savings = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Savings")
    ave_spent = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Percantage")
    ave_income_spent = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Percantage")
    budgetRange = models.CharField(max_length=100, verbose_name="Budget Range",null=True, blank = True)

    def __str__(self):
        return self.budgetName


class income(models.Model):
    budgetID = models.ForeignKey(budget, verbose_name='User Budget', on_delete=models.CASCADE)
    incomeAmount = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Income Amount")
    incomeCategories = models.CharField(max_length=100, verbose_name="Income Categories")

    def __str__(self):
        return self.incomeCategories

class expenses(models.Model):
    budgetID = models.ForeignKey(budget, verbose_name='User Budget', on_delete=models.CASCADE)
    expensesAmount = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Expediture Amount")
    expensesCategories = models.CharField(max_length=100, verbose_name="Income Categories")
    expensesTotal = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Expenditure Spent")
    balanceRemain = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Balance Remaining")
    ave_spent = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Percantage")
    
    def __str__(self):
        return self.expensesCategories


class expenseSpent(models.Model):
    expenseID = models.ForeignKey(expenses, verbose_name='Expenditure', on_delete=models.CASCADE)
    amountSpent = models.DecimalField(decimal_places=2,max_digits=20,default=0.00, verbose_name="Amount Spent")
    description = models.CharField(max_length=100, verbose_name="Description", )
    transactionDate = models.DateField(max_length=100, verbose_name="Transaction Date", null=True, blank = True)
  
    def __str__(self):
        return self.expenseID.expensesCategories



