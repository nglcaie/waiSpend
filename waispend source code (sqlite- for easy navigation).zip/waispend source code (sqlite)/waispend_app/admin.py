from django.contrib import admin
from .models import *

admin.site.site_header = 'Waispend'
admin.site.index_title = 'Waispend Database'
admin.site.site_title = 'Waispend Administration'
# Register your models here.



admin.site.register(expenses),
admin.site.register(expenseSpent),

class budgetAdmin(admin.ModelAdmin):
    model = budget
    list_display = ('get_id','userID','budgetName','budgetPurpose','totalIncome','totalBudgeted')

    def get_id(self, obj):
        return obj.id

    def budgetName(self, obj):
        return obj.userID.budgetName

    def budgetPurpose(self, obj):
        return obj.userID.budgetPurpose

    def totalIncome(self, obj):
        return obj.userID.totalIncome

    def totalBudgeted(self, obj):
        return obj.userID.totalBudgeted

admin.site.register(budget,budgetAdmin)

class incomeAdmin(admin.ModelAdmin):
    model = income
    list_display = ('get_id','budgetID','incomeCategories','incomeAmount')

    def get_id(self, obj):
        return obj.id

    def budgetID(self, obj):
        return obj.budgetID

    def incomeCategories(self, obj):
        return obj.budgetID.incomeCategories

    def incomeAmount(self, obj):
        return obj.budgetID.incomeAmount

admin.site.register(income,incomeAdmin)



