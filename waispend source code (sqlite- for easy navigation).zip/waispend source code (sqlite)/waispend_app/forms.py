from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.models import User
from django import forms



class CreateUserForm(UserCreationForm):
    def __init__(self,*args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["first_name"].widget.attrs.update({'required':True,'name':'first_name','id':'first_name','type':'text','class':'form-control-R1','placeholder':'First Name'})
        self.fields["last_name"].widget.attrs.update({'required':True,'name':'last_name','id':'last_name','type':'text','class':'form-control-R1','placeholder':'Last Name'})
        self.fields["email"].widget.attrs.update({'required':True,'name':'email','id':'email','type':'text','class':'form-control','placeholder':'Email'})
        self.fields["username"].widget.attrs.update({'required':True,'name':'username','id':'username','type':'text','class':'form-control','placeholder':'Username'})
        self.fields["password1"].widget.attrs.update({'required':True,'name':'password1','id':'password1','type':'password','class':'form-control','placeholder':'Password'})
        self.fields["password2"].widget.attrs.update({'required':True,'name':'password2','id':'password2','type':'password','class':'form-control','placeholder':'Confirm Password'})
        
    class Meta:
        model = User
        fields = ['first_name','last_name','email','username','password1','password2']

class PasswordChangingForm(PasswordChangeForm):
    def __init__(self,*args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["old_password"].widget.attrs.update({'required':True,'name':'old_password','id':'old_password','type':'password','class':'form-control','placeholder':'Current Password'})
        self.fields["new_password1"].widget.attrs.update({'required':True,'name':'new_password1','id':'new_password1','type':'password','class':'form-control','placeholder':'Password'})
        self.fields["new_password2"].widget.attrs.update({'required':True,'name':'new_password2','id':'new_password2','type':'password','class':'form-control','placeholder':'Confirm Password'})
        
    class Meta:
        model = User
        fields = ['old_password','new_password1','new_password2']